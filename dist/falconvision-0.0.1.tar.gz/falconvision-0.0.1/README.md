﻿# FalconVision gives insight on Minecraft servers
# 
# python3 -m FalconVision -host mc.example.com -port 25565 -protocol 770
