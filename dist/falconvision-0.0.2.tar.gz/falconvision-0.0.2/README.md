﻿# FalconVision gives insight on Minecraft servers. It also downloads the server favicon if available.
# 
# python3 -m FalconVision -host mc.example.com -port 25565 -protocol 770
